# PyARES #
## Requirements ##
Python 3.4
- Numpy == 1.14.5
- Happybase == 1.1.0
- Pandas == 0.20.3
- PyMySQL == 0.8.0
- Protobuf == 3.0.0
- Pyarrow == 0.9.0

Best practice:
- Create a clean Python 3.4.1 virtual environment with pip, wheel and setuptools included
- Activate the virtual environment
- Install the pyares source distribution in the `dist/` folder of this repository using pip (`pip install pyares-*.tar.gz`)
- Take care of proper configuration with `pyares_conf.ini`

Folder dist contains the wheel to install with pip (version 0.1.0). The installation should automatically take care of the dependencies. The conf file can be found in the pyares folder of the site-packages, in the conf subfolder.

The data retrieval needs a machine that can access the MariaDB and HBase instances. The only configuration that you need to take care of is the HBase and MariaDB ones, the rest you can ignore.

For job submission and result retrieval the machine needs to be configured as an ARES gateway and some additional configurations. 
On a gateway node, make sure that `yarn` and `spark-submit` are in the PATH. Usually, they can be found in `/opt/cloudera/parcels/CDH/bin`. In this case you need to edit the rest of the config file as well.

## Data Retrieval ##
Data retrieval from HBase is functional, all other methods are considered under construction.

### Usage ###

```python
import pyares as pa

# Initalize the needed datasources. Right now this is hardcoded into the initializer, so for config you need to manage this yourself.
data_provider = pa.init_param_sampleprovider()

# Get some params that you want to look for and of course some times as well
params = ['NPWD2491', 'NPWD2501', ... , 'NPWD2691', 'NPWD2692']
timestamp_start = 1387324800000
timestamp_end = 1388584759000

# Get the data from HBase and transform into Pandas DF
df = data_provider.get_parameter_data_df(params, timestamp_start, timestamp_end)
print(df.shape)

# Or, if you prefer, get them into sample objects and get information from the objects.
# The method returns a nested generator.
samples = data_provider.get_parameter_data_objs(params, timestamp_start, timestamp_end)
for sample in samples:
    for s in sample:
        print(s.get_value())
```

### Version 0.1.0 ###
As of version 0.1.0 pyares has the following features:
- `init_param_sampleprovider()`; Constructor that automatically initializes the connection to HBase and other resources based on the config file.
- `get_param_name_list()`; (DEPRECATED Recommend usage of `get_param_metadata_df()`)Gets all the parameter names from the MariaDB in a list.
- `get_param_metadata_df()`; Get parameter metadata from the MariaDB in a Pandas DF.
- `get_param_data_df()`; For a given n parameters in list (or string if n=1) and given start and end timestamp, fetch all the data into a Pandas dataframe.
- `get_param_data_obj()`; For a given n parameters in list (or string if n=1) and given start and end timestamp, fetch all the data into sample objects.

## Ares Job submission##
Ares Job submissions work, but still need to be heavily optimized.

### Usage ###
Executing an Ares Job requires two pieces of code: the script calling the execution and the script defining the fuctions.
The script calling the execution of the job also declares what data will be processed.
```
import pyares as pa

params = ["sa","sx","sy","sz"]
timestamps = sorted([1387324800000, 1388584759000])

data_provider = pa.init_aresjob()
job_id = data_provider.execute_job(script='spark_job.py',
                                   param_names=params, start=timestamps[0], end=timestamps[-1])
                                   
# Optional while loop to wait until the job is finished.
while True:
    sleep(15)
    status = data_provider.get_job_status()
    print(status)
    if status['Final-State'] == 'SUCCEEDED':
        print('Job succeeded')
        break
    if status['Final-State'] == 'FAILED':
        print("Job failed.")
        break
```
The script used to define the functions to be executed on the data.
```
import numpy as np
import pyares as pa

def calc_avg(data):
    return np.mean(data)

def calc_add(data):
    return np.add(data, 100)

aj = pa.init_aresjob()
result = aj.define_job(f=[calc_add], persist_search=True, calc_stats=True)
```

### Version 0.1.0 ###
Under construction, will include Ares job and data return from cluster.
- `init_aresjob()`; Constructor for Ares jobs
- `define_job()`; Create a job for a given function f with n parameters in list (or string if n=1) and given start and end timestamp.
- `execute_job()`; Executes the Ares job on the cluster. Needs the script containing the functions to execute, as well as the data (params, start, end).
- `get_job_status()`; Gets the job status for a given job id. Job id is optional and part of the class instance for the last submitted job.

## Result Retrieval ##
The results from the Ares job can be retrieved with the result retriever.

### Usage ###
```
import pyares as pa

retriever = pa.init_param_jobresultretriever()

# Fetch the results for each result type available.
print(retriever.get_job_result_df(job_id=job_id, result_type='search'))
print(retriever.get_job_result_df(job_id=job_id, result_type='stat'))
print(retriever.get_job_result_df(job_id=job_id, result_type='udf'))
```

### Version 0.1.0 ###
As of version 0.1.0 the result retriever has the following functions:
- `get_job_result_df()`; Gets the result of the job from HDFS for a given job id in the form of a pandas dataframe. Depending on the definitions in the job submitted, the results can be from the search, the statistics and/or the user defined functions.
